import random
import tkinter as tk
class Player:
    def __init__(self,name):
        self.name=name
        self.score=10
class Game:
    def __init__(self):#creating the constructor with base window, its size and a random number that will be generated once for every player
        self.root=tk.Tk()
        self.root.title("Number Guessing Game")
        self.root.geometry("300x300")
        self.secret_number=random.randint(0,10)
        self.lives=5#every player gets only 5 guesses
        self.display_rules()
    def display_rules(self):#this will display the rules on the window
        self.rules_label=tk.Label(self.root,text="Following are the rules of this game:\n\n\n1. <<You have to guess a random number>>\n (ranging from 0 to 10).\n2. Every wrong guess will cost you:\nI. 1 life\nII. 2 points from your score.\n3. You will only be given 5 lives.\n'Better guess wisely!\nClick 'Play' if you understand the rules.",font=('Arial', 11),bg='pink')
        self.rules_label.pack(pady=10)
        self.rules_button=tk.Button(self.root,text="Play", command=self.play_ahead)  
        self.rules_button.pack(pady=10)
        self.root.mainloop()
    def play_ahead(self):#this will remove the rules from the window
        self.rules_label.destroy()
        self.rules_button.destroy()
        self.player_info()
    def player_info(self):#this will take the player's name as input
        self.greet_label=tk.Label(self.root, text="\nWELCOME!",font=('Arial',18),fg='grey')
        self.greet_label.pack()
        self.info_label=tk.Label(self.root,text="Enter your name:",font=('Arial',14),fg='grey')
        self.info_label.pack(pady=10)
        self.info_entry=tk.Entry(self.root)
        self.info_entry.pack()
        self.info_button=tk.Button(self.root,text="Enter",command=self.startGame)
        self.info_button.pack()
    def startGame(self):#this will remove the player's info page and start the game
        name=self.info_entry.get()
        if not name.strip():#if user enters no name, game will not continue
            self.info_label.config(text="Enter valid name!")
            return
        self.player=Player(name)
        self.greet_label.destroy()
        self.info_label.destroy()
        self.info_button.destroy()
        self.info_entry.destroy()
        self.game_interface()
    def game_interface(self):#game interface is set in this class
        top_frame = tk.Frame(self.root)#a top frame built for life and score updates
        top_frame.pack(fill=tk.X, side=tk.TOP,anchor='n')#top frame is set on the upper x-axis directioned towards north
        #a life update button is made to keep the player updated
        self.life_button = tk.Button(top_frame, text='❤️❤️❤️❤️❤️', font=('Arial', 9), command=self.decrease_life)
        self.life_button.pack(side=tk.RIGHT, padx=10, pady=10)
        #a score button is also made that updates with every wrong guess
        self.score_button=tk.Button(top_frame,text=f"{self.player.score}",command=self.decrease_score)
        self.score_button.place(x=0,y=0)
        self.label = tk.Label(self.root,text=f"{self.player.name}\nTake a guess!",font=("Arial",13),bg="pink", fg="grey")
        self.label.pack(pady=20)
        #an entry where player can input their guess
        self.entry=tk.Entry(self.root)
        self.entry.pack()
        self.play_game = PlayGame(self,self.player)
        self.button = tk.Button(self.root, text="Submit",font=('Arial',12), command=self.play_game.check_number)
        self.button.place(x=115,y=180)
        #adding a button that would allow player to restart the game.
        self.restart_button=tk.Button(self.root,text="Restart",font=('Arial',8),command=self.restart_game)
        self.restart_button.place(x=125,y=210)
    def restart_game(self):#instructions for restarting the game
        self.life_button.destroy()
        self.label.destroy()
        self.button.destroy()
        self.score_button.destroy()
        self.entry.destroy() 
        self.restart_button.destroy()
        self.playagain_button.destroy()
        Game()
    def decrease_life(self):#this method will decrease the life incase of wrong guess, and also update the display
        if self.lives > 0:
            self.lives -= 1
            self.update_life_display()
    def decrease_score(self):#this method will decrease the scoreof the user and update the score display
        if self.player.score>0:
            self.player.score-=2
            self.update_score_display()
    def update_life_display(self):
        hearts = '❤️' * self.lives
        self.life_button.config(text=hearts)
        if self.lives == 0:
            self.label.config(text="Game Over!",font=('Arial',16))
            self.life_button.config(text="☠️")
            self.entry.destroy()
            self.button.destroy()
            self.restart_button.destroy()
            self.playagain_button=tk.Button(self.root,text="Play Again", command=self.restart_game)#this button appears after game is over and let's player play again
            self.playagain_button.pack()
            return
    def update_score_display(self):
        self.score_button.config(text=self.player.score)
class PlayGame:#this class inherits info from game and player class.
    def __init__(self,Game,Player):
        self.game=Game
        self.player=Player
    def check_number(self):
        guess_text=self.game.entry.get()
        if not guess_text.strip():#error handlin to ensure no value error occurs
            self.game.label.config(text="Enter a number!")
            return
        try:
            guess = int(guess_text)#inheriting the guess given by the player
        except ValueError:
            self.game.label.config(text="Enter a valid number!")
        secret = self.game.secret_number#inheriting from game class
        #generating labels based on whether the guess is correct or incorrect

        if guess>10:
            self.game.label.config(text="You really need to re-read the rules.\nBetter use your glasses this time!")
        if guess == secret:
            self.game.entry.destroy()
            self.game.button.destroy()
            self.game.restart_button.destroy() 
            self.game.label.config(text="Congratulations!\nYou Won\n.\nYou have a really special gift of intuition.",font=('Arial',12),fg="grey",bg='pink')  
            return
        elif guess!=secret:
            self.game.decrease_life()
            self.game.decrease_score()
            if self.player.score<=0 or self.game.lives<=0:
                return
            #generating hints
            if self.player.score == 2:
                self.game.label.config(text="You're not just wrong!\nYou're passionately wrong!")
            elif self.player.score == 4:
                self.game.label.config(text="Nice try! If I were a number, I'd hide too!")
            elif secret == 0:
                self.game.label.config(text="Hint:\nI swear you're worrying over nothing!")
            elif secret != 0 and guess % secret == 0 and guess!=0:
                self.game.label.config(text="Hint:\nYour guess is a multiple!")
            elif guess % 4 != 0 and secret % 4 == 0:
                self.game.label.config(text="Hint:\nYour guess is not divisible by 4. Mine is!")
            elif guess % 3 != 0 and secret % 3 == 0:
                self.game.label.config(text="Hint:\nYour guess is not divisible by 3. Mine is!")
            elif guess % 2 != 0 and secret % 2 == 0:
                self.game.label.config(text="Hint:\nYour guess is too odd for my even taste!")
            elif guess % 2 == 0 and secret % 2 != 0:
                self.game.label.config(text="Hint:\nYour guess is too even for my odd taste!")
            elif abs(guess - secret) == 1:
                self.game.label.config(text="Hint:\nSooo close! You're making me hopeful!")
            elif guess - secret == 5:
                self.game.label.config(text="Hint:\nA little bit too high! Bring it down a notch.")
            elif guess - secret == -5:
                self.game.label.config(text="Hint:\nA little bit too low! Aim a little higher.")
            elif guess > secret:
                self.game.label.config(text="Hint:\nYour guess is too high!")
            elif guess < secret:
                self.game.label.config(text="Hint:\nYour guess is too low!")
Game()#initiating the game